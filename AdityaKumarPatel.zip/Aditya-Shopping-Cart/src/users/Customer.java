package users;

import java.util.ArrayList;
import java.util.List;

public class Customer {

	private String name;
	private CustomerType type;

	public List<Double> items = new ArrayList<>();
	
	public Customer(CustomerType type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	
	public CustomerType getType() {
		return type;
	}

	public void setType(CustomerType type) {
		this.type = type;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Double> getItems() {
		return items;
	}

	public void setItems(List<Double> items) {
		this.items = items;
	}
	
	

}
