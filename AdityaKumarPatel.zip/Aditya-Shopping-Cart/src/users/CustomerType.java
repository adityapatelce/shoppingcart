package users;

import java.util.ArrayList;
import java.util.List;

public class CustomerType {

	public static CustomerType REGULAR = new CustomerType("REGULAR");
	public static CustomerType PREMIUM = new CustomerType("PREMIUM");

	public static List<CustomerType> types = new ArrayList<>();

	static {
		types.add(REGULAR);
		types.add(PREMIUM);
	}

	String type = "";

	public CustomerType(String type) {
		this.type = type;
	}

	public static CustomerType getCustomeType(String typ) {

		if (types.contains(typ)) {
			return types.get(types.indexOf(typ));
		}
		return null;
	}

	public static CustomerType addCustomeType(String typ) {

		if (types.contains(typ)) {
			return types.get(types.indexOf(typ));
		}

		CustomerType customerType = new CustomerType(typ);
		types.add(customerType);
		return customerType;
	}
}
