package slabs;

import users.CustomerType;

public class DiscountSlab {

	private double min;
	private double max;

	private float discountPercentage = 0;

	private CustomerType cutomerType;

	public DiscountSlab(CustomerType type, double min, double max) {
		this.cutomerType = type;
		this.min = min;
		this.max = max;
	}

	public CustomerType getCutomerType() {
		return cutomerType;
	}

	public void setCutomerType(CustomerType cutomerType) {
		this.cutomerType = cutomerType;
	}

	public DiscountSlab(CustomerType type, double min, double max,
			float discount) {
		this(type, min, max);
		this.discountPercentage = discount;
	}

	public double getMin() {
		return min;
	}

	public void setMin(double min) {
		this.min = min;
	}

	public double getMax() {
		return max;
	}

	public void setMax(double max) {
		this.max = max;
	}

	public float getDiscountPercentage() {
		return discountPercentage;
	}

	public void setDiscountPercentage(float discountPercentage) {
		this.discountPercentage = discountPercentage;
	}

}
