package slabs;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import users.CustomerType;

public class DiscountSlabService {

	private List<DiscountSlab> discountSlabs = new ArrayList<DiscountSlab>();

	public static final DiscountSlabService INSTANCE = new DiscountSlabService();

	private DiscountSlabService() {
		// Regular Customers
		addDiscountForRegularCustomer(0.0, 5000.0, 0);
		addDiscountForRegularCustomer(5000.0, 10000.0, 10);
		addDiscountForRegularCustomer(10000.0, Double.MAX_VALUE, 20);

		// Premimum Customers
		addDiscountForPremium(0.0, 4000.0, 10);
		addDiscountForPremium(4000.0, 8000.0, 15);
		addDiscountForPremium(8000.0, 12000.0, 20);
		addDiscountForPremium(12000.0, Double.MAX_VALUE, 30);
	}

	private List<DiscountSlab> isSlabExists(CustomerType customerType,
			double minimumSlab, double maximumSlab) {

		List<DiscountSlab> existDiscountSlab = discountSlabs
				.stream()
				.filter((slab) -> {
					return (slab.getMin() == minimumSlab && slab.getMax() == maximumSlab)
							&& slab.getCutomerType() == customerType;
				}).collect(Collectors.toList());

		return existDiscountSlab;
	}

	// Add Discount
	public void addDiscount(CustomerType customerType, double minimumSlab,
			double maximumSlab, float discount) {

		if(minimumSlab > maximumSlab ) {
			throw new RuntimeException("Enter Invalid slabs : minimum slab should be greater than maximum slab");
		}
		
		if (isSlabExists(customerType, minimumSlab, maximumSlab).isEmpty()) {

			discountSlabs.add(new DiscountSlab(customerType, minimumSlab,
					maximumSlab, discount));
		} else {
			throw new RuntimeException("Slab is already exist");
		}

	}

	public void addDiscountForRegularCustomer(Double minimumSlab,
			Double maximumSlab, float i) {
		addDiscount(CustomerType.REGULAR, minimumSlab, maximumSlab, i);
	}

	public void addDiscountForPremium(double minimumSlab, double maximumSlab,
			float discount) {
		addDiscount(CustomerType.PREMIUM, minimumSlab, maximumSlab, discount);
	}

	// Get Slab
	public DiscountSlab getSlab(CustomerType customerType, double itemAmout) {
		return discountSlabs
				.stream()
				.filter((slab) -> {
					return (itemAmout >= slab.getMin() && itemAmout <= slab
							.getMax()) && slab.getCutomerType() == customerType;
				}).findFirst().orElseGet(() -> null);
	}
}
