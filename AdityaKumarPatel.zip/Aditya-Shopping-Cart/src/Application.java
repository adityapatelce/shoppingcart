import Billing.ItemAmountService;
import slabs.DiscountSlabService;
import users.Customer;
import users.CustomerType;

public class Application {

	// During initialize object , we have loaded default discounts as per
	// guidelines .
	static DiscountSlabService discountSlabService = DiscountSlabService.INSTANCE;

	// These service is used to get actual amount after calculating discount on
	// selected item .
	static ItemAmountService itemAmountService = new ItemAmountService();

	public static void main(String[] args) {

		Customer customer = new Customer(CustomerType.REGULAR);

		itemAmountService.addItem(customer, 10000);
		itemAmountService.addItem(customer, 10000);

		System.out.println(itemAmountService.getFinalAmount(customer));
		
		
		System.out.println("============= PREMIUM =================");
		Customer customer2 = new Customer(CustomerType.PREMIUM);

		itemAmountService.addItem(customer2, 4000);
		itemAmountService.addItem(customer2, 4000);
		itemAmountService.addItem(customer2, 4000);
		itemAmountService.addItem(customer2, 8000);

		System.out.println(itemAmountService.getFinalAmount(customer2));

		/*
		 * // Add Discounts discountSlabService.addDiscountForPremium(12.0,
		 * 100.0, 35); discountSlabService.addDiscountForRegularCustomer(12.0,
		 * 100.0, 35);
		 * 
		 * discountSlabService.addDiscount(CustomerType.PREMIUM, 150, 200.0,
		 * 35);
		 * 
		 * // Add Type CustomerType.addCustomeType("GOLD");
		 * 
		 * discountSlabService.addDiscount(CustomerType.getCustomeType("GOLD"),
		 * 3000, 5000, 15);
		 * 
		 * // Get Expected amount after calculate with discount charge . double
		 * amountGold = itemAmountService.getBillAmount(
		 * CustomerType.getCustomeType("GOLD"), 4000);
		 * System.out.println("GOLD => " + 4000 + " Expected:" +amountGold);
		 * 
		 * // Regular double amountR1 =
		 * itemAmountService.getBillAmount(CustomerType.REGULAR, 5000);
		 * System.out.println("REGULAR => " + 5000 + " Expected:" + amountR1);
		 * double amountR2 =
		 * itemAmountService.getBillAmount(CustomerType.REGULAR, 10000);
		 * System.out.println("REGULAR => " + 10000 + " Expected:" + amountR2);
		 * double amountR3 =
		 * itemAmountService.getBillAmount(CustomerType.REGULAR, 15000);
		 * System.out.println("REGULAR => " + 15000 + " Expected:" + amountR3);
		 * 
		 * // Premimum double amountp1 =
		 * itemAmountService.getBillAmount(CustomerType.PREMIUM, 4000);
		 * System.out.println("PREMIUM => " + 4000 + " Expected:" + amountp1);
		 * double amountP2 =
		 * itemAmountService.getBillAmount(CustomerType.PREMIUM, 8000);
		 * System.out.println("PREMIUM => " + 8000 + " Expected:" + amountP2);
		 * double amountp3 =
		 * itemAmountService.getBillAmount(CustomerType.PREMIUM, 12000);
		 * System.out.println("PREMIUM => " + 12000 + " Expected:" + amountp3);
		 * double amountp4 =
		 * itemAmountService.getBillAmount(CustomerType.PREMIUM, 20000);
		 * System.out.println("PREMIUM => " + 20000 + " Expected:" + amountp4);
		 */
	}
}
