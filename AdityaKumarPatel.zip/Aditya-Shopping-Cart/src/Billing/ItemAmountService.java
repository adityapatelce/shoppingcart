package Billing;


import slabs.DiscountSlab;
import slabs.DiscountSlabService;
import users.Customer;

public class ItemAmountService {

	private DiscountSlabService discountSlabService = DiscountSlabService.INSTANCE;

	public double getFinalAmount(Customer customer) {

		double totalAmount = customer.getItems().stream()
				.mapToDouble(Double::doubleValue).sum();

		double finalAmmount = 0;
		while (totalAmount != 0) {

			DiscountSlab discountSlab = discountSlabService.getSlab(customer.getType(), totalAmount);

			double diffAmount = totalAmount - discountSlab.getMin();
			finalAmmount += getActualAmount(discountSlab, diffAmount);
			totalAmount -= diffAmount;
		}

		return finalAmmount;

	}

	public void addItem(Customer customer, double item) {
		customer.getItems().add(item);
	}

	private double getActualAmount(DiscountSlab slab, double purchaseAmount) {
		float discount = slab == null ? 0 : slab.getDiscountPercentage();

		return (purchaseAmount - (purchaseAmount * discount) / 100);
	}
}
